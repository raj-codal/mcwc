package com.example.practical9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox c,b,t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c = findViewById(R.id.cricket);
        b = findViewById(R.id.badminton);
        t = findViewById(R.id.tennis);
    }

    public void f(View view){
        String x = "";
        if(c.isChecked()){
            x+="Cricket\n";
        }
        if(b.isChecked()){
            x+="Badminton\n";
        }
        if(t.isChecked()){
            x+="Tennis\n";
        }
        Toast.makeText(this,x,Toast.LENGTH_SHORT).show();
    }
}
