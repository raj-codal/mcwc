package com.example.practical10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    String old, current, prevOp;
    EditText x;
    Button _0,_1,_2,_3,_4,_5,_6,_7,_8,_9,mul,div,plus,minus,eq,dot;
    boolean flag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        old = "0";
        current = "0";
        x = (EditText) findViewById(R.id.input);
        _0 = (Button) findViewById(R.id._0);
        _1 = (Button) findViewById(R.id._1);
        _2 = (Button) findViewById(R.id._2);
        _3 = (Button) findViewById(R.id._3);
        _4 = (Button) findViewById(R.id._4);
        _5 = (Button) findViewById(R.id._5);
        _6 = (Button) findViewById(R.id._6);
        _7 = (Button) findViewById(R.id._7);
        _8 = (Button) findViewById(R.id._8);
        _9 = (Button) findViewById(R.id._9);
        mul = (Button) findViewById(R.id.mul);
        div = (Button) findViewById(R.id.div);
        minus = (Button) findViewById(R.id.minus);
        plus = (Button) findViewById(R.id.plus);
        dot = (Button) findViewById(R.id.dot);
        eq = (Button) findViewById(R.id.eq);
        _0.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "0";
                x.setText(current);
            }
        });
        _1.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "1";
                x.setText(current);
            }
        });
        _2.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "2";
                x.setText(current);
            }
        });
        _3.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "3";
                x.setText(current);
            }
        });
        _4.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "4";
                x.setText(current);
            }
        });
        _5.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "5";
                x.setText(current);
            }
        });
        _6.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "6";
                x.setText(current);
            }
        });
        _7.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "7";
                x.setText(current);
            }
        });
        _8.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "8";
                x.setText(current);
            }
        });
        _9.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += "9";
                x.setText(current);
            }
        });
        dot.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                if(flag){
                    flag = false;
                    current = "";
                }
                current += ".";
                x.setText(current);
            }
        });
        plus.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                double a,b;
                a = Double.parseDouble(old);
                b = Double.parseDouble(current);
                a += b;
                System.out.println(a+" "+b);
                current = new String(Double.toString(a));
                old = current;
                x.setText(current);
                flag = true;
                prevOp = "+";
            }
        });
        minus.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                double a,b;
                a = Double.parseDouble(old);
                b = Double.parseDouble(current);
                a -= b;
                System.out.println(a+" "+b);
                current = new String(Double.toString(a));
                old = current;
                x.setText(current);
                flag = true;
                prevOp = "-";
            }
        });
        mul.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                double a,b;
                a = Double.parseDouble(old);
                b = Double.parseDouble(current);
                a *= b;
                System.out.println(a+" "+b);
                current = new String(Double.toString(a));
                old = current;
                x.setText(current);
                flag = true;
                prevOp = "*";
            }
        });
        div.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                double a,b;
                a = Double.parseDouble(old);
                b = Double.parseDouble(current);
                a /= b;
                System.out.println(a+" "+b);
                current = new String(Double.toString(a));
                old = current;
                x.setText(current);
                flag = true;
                prevOp = "/";
            }
        });
        eq.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                double a,b;
                a = Double.parseDouble(old);
                b = Double.parseDouble(current);
                switch (prevOp.charAt(0)){
                 '0': a += b;
                    break;
                }
                System.out.println(a+" "+b);
                current = new String(Double.toString(a));
                old = current;
                x.setText(current);
                flag = true;
            }
        });
    }
}
