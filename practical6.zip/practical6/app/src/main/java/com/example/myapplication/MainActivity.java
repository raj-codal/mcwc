package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import android.widget.TextView;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public static String uname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Login(View v){
        EditText t1 = (EditText) findViewById(R.id.email);
        EditText t2 = (EditText) findViewById(R.id.password);
        TextView t3 = (TextView)findViewById(R.id.t1);
        if(t1.getText().toString().equalsIgnoreCase("raj@gmail.com") && t2.getText().toString().equalsIgnoreCase("123")){
            t3.setText("LOGGED IN");
            Intent i = new Intent(this, Main2Activity.class);
            uname = t1.getText().toString();
            i.putExtra("uname", t1.getText().toString());
            startActivity(i);
        }
        else{
            t3.setText("WRONG PASSWORD");
        }

    }

}
